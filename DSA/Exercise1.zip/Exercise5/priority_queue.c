/*






*/
#include<stdio.h>
#include<stdlib.h>
#define SIZE 10

struct queue{
    int rear;
    int priority[SIZE];
    int data[SIZE];
}q;

int isqempty()
{
    if(q.rear == -1)
        return 1;
    else
        return 0;
}

int isqfull()
{
    if(q.rear == SIZE -1 )
        return 1;
    else
        return 0;
}

void enqueue(int val,int pri)
{
    if(isqfull())
    {
        printf("\n Overflow");
        return;
    }
    else
    {
        q.rear++;
        q.data[q.rear] = val;
        q.priority[q.rear] = pri;
    }
}

void dequeue()
{
    if(isqempty())
    {
        printf("\n Underflow");
        return;
    }
    int max,i;
    max=0;
    for(i = 1; i <= q.rear; i++)
    {
        if(q.priority[i] < q.priority[max])
        {
            max = i;
        }
    }
    printf("\n Deleted Element %d[%d]",q.data[max],q.priority[max]);
    for(i = max;i <= q.rear; i++)
    {
        q.priority[i]=q.priority[i+1];
        q.data[i]=q.data[i+1];
    }
    q.rear--;
}

void display()
{
    if(isqempty())
    {
        printf("\n Underflow");
        return;
    }
    int i;
    for(i=0;i<=q.rear;i++)
    {
        printf("\t%d [%d] ->",q.data[i],q.priority[i]);
    }
}

void main()
{
    q.rear=-1;
    int ch,val,pri;
    while(1)
    {
        printf("\n1. Display");
        printf("\n2. Add");
        printf("\n3. Delete");
        printf("\n4. Exit");

        printf("\n Enter your choice : ");
        scanf("%d",&ch);
        switch(ch)
        {
        case 1:
            display();
            break;
        case 2:
            printf("\nEnter Data and priority : ");
            scanf("%d %d",&val,&pri);
            enqueue(val,pri);
            break;
        case 3:
            dequeue();
            break;
        case 4:
            exit(1);

        default:
            printf("\n Invalid choice");
            break;

        }
    }
}
